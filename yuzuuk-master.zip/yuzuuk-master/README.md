<div align="center">
<img src="https://cdn.discordapp.com/attachments/1162976102034198591/1277782256160739468/2392edec5ba1037f4d5dc3c59a098700.png?ex=66ce6af5&is=66cd1975&hm=f7af7731e38a4df4c333f759eebcce9e18244d0cdc6c9b9e8b6a790b2e66e852&" width="25%" align="right" />
<img src="https://readme-typing-svg.herokuapp.com?font=Montserrat&duration=3000&pause=1000&color=F7F7F7&center=true&vCenter=true&width=435&lines=Howdy!+I'm+Yuzuk.;JavaScript+%7C+Lua+%7C+Ruby+%7C+Python;Creating+cool+stuff+with+code!+%F0%9F%9A%80" width="70%" />
<br><br>
<pre>
    💼 Back-end dev • Platform Engineer
    💻 System programming languages
    🎮 Music • Games • Anime • Code • Art
</pre>
<br><br>
<img src="https://raw.githubusercontent.com/innng/innng/master/assets/kyubey.gif" height="40" />
</div>
